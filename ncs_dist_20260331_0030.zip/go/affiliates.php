<?php

declare(strict_types=1);

const GO_SUBID_PARAM = 'subid';
const GO_MODEL_PROGRAM_CONFIG = [
    'bonga' => [
        'active' => true,
        'tiers' => ['T1', 'T2', 'T3', 'T4'],
    ],
    'camsoda' => [
        'active' => true,
        'tiers' => ['T1', 'T2', 'T3', 'T4'],
    ],
    'chaturbate' => [
        'active' => true,
        'tiers' => ['T1', 'T2', 'T3', 'T4'],
    ],
    'fansly' => [
        'active' => true,
        'tiers' => ['T1', 'T2', 'T3', 'T4'],
    ],
];

/**
 * Append a subid query parameter to the provided URL.
 */
function go_append_subid(string $url, string $subid): string
{
    if ($subid === '') {
        return $url;
    }

    $separator = strpos($url, '?') === false ? '?' : '&';

    return $url . $separator . GO_SUBID_PARAM . '=' . rawurlencode($subid);
}

/**
 * Normalise tracking values so they are safe to include in subids.
 */
function go_normalize_tracking_value(null|string $value, string $fallback): string
{
    $normalized = is_string($value) ? trim($value) : '';

    if ($normalized === '') {
        return $fallback;
    }

    $sanitized = preg_replace('/[^A-Za-z0-9_.-]+/', '_', $normalized);
    if (!is_string($sanitized) || $sanitized === '') {
        return $fallback;
    }

    return trim($sanitized, '_') ?: $fallback;
}

/**
 * Normalise an optional YYYYMMDD stamp.
 */
function go_normalize_tracking_date(null|string $value): string
{
    $candidate = is_string($value) ? trim($value) : '';
    if ($candidate !== '' && preg_match('/^\d{8}$/', $candidate) === 1) {
        return $candidate;
    }

    return gmdate('Ymd');
}

/**
 * Extract the base tracking payload used for all redirects.
 *
 * @return array{src: string, camp: string, date: string, subid: string}
 */
function go_extract_tracking_params(): array
{
    $src = go_normalize_tracking_value($_GET['src'] ?? null, 'direct');
    $camp = go_normalize_tracking_value($_GET['camp'] ?? null, 'default');
    $date = go_normalize_tracking_date($_GET['date'] ?? null);

    return [
        'src' => $src,
        'camp' => $camp,
        'date' => $date,
        'subid' => sprintf('%s|%s|%s', $src, $camp, $date),
    ];
}

/**
 * Send a 302 redirect with the required caching headers.
 */
function go_send_redirect(string $location): void
{
    $destination = $location !== '' ? $location : '/';

    if (!headers_sent()) {
        header('Cache-Control: no-store');
        header('Location: ' . $destination, true, 302);
    }

    exit;
}

/**
 * Toggle lookup helper that supports environment overrides.
 */
function go_model_program_is_active(string $programKey, string $tier): bool
{
    $config = GO_MODEL_PROGRAM_CONFIG[$programKey] ?? null;
    if ($config === null) {
        return false;
    }

    $envKey = 'GO_MODEL_PROGRAM_' . strtoupper($programKey) . '_ENABLED';
    $override = go_resolve_env_flag($envKey);
    $enabled = $override ?? (($config['active'] ?? false) === true);

    if (!$enabled) {
        return false;
    }

    $allowedTiers = $config['tiers'] ?? [];
    if ($allowedTiers === [] || in_array($tier, $allowedTiers, true)) {
        return true;
    }

    return false;
}

/**
 * Resolve an environment flag from supported sources.
 */
function go_resolve_env_flag(string $key): ?bool
{
    $sources = [$_ENV, $_SERVER];

    foreach ($sources as $source) {
        if (!isset($source[$key])) {
            continue;
        }

        $value = strtolower((string) $source[$key]);
        if (in_array($value, ['1', 'true', 'on', 'yes'], true)) {
            return true;
        }

        if (in_array($value, ['0', 'false', 'off', 'no'], true)) {
            return false;
        }
    }

    return null;
}

/**
 * Dispatch to the correct model program builder.
 */
function go_build_model_program_url(string $programKey, string $subid, array $context = []): ?string
{
    return match ($programKey) {
        'bonga' => go_build_bonga_model_signup($subid, $context),
        'camsoda' => go_build_camsoda_model_signup($subid),
        'chaturbate' => go_build_chaturbate_model_signup($subid),
        'fansly' => go_build_fansly_creator_signup($subid),
        default => null,
    };
}

/**
 * Default fallback when no affiliate program is active.
 */
function go_model_fallback_url(string $subid): string
{
    return go_append_subid('/apply/', $subid);
}

function go_build_bonga_model_signup(string $subid, array $context = []): string
{
    // TODO: if panel uses a different subid key, change here and in programs.json
    $subKey = 's1';

    // Single base for now; if you get tier-specific refs, branch on $tier
    $base = 'https://bongacash.com/model-ref?c=828873';

    // Append subid
    $sep = (strpos($base, '?') === false) ? '?' : '&';
    $url = $base . $sep . $subKey . '=' . rawurlencode($subid);

    return $url;
}

function go_build_camsoda_model_signup(string $subid): string
{
    $base = 'https://www.camsoda.com/' . 'models?id=naughtycamboss';
    $tracking = $subid !== '' ? $subid : 'default';

    return go_append_subid($base, $tracking);
}

function go_build_chaturbate_model_signup(string $subid): string
{
    $tracking = $subid !== '' ? $subid : 'default';

    return 'https://chaturbate.com/in/?tour=5zjT&campaign=YIOhf&track=' . rawurlencode($tracking);
}

function go_build_fansly_creator_signup(string $subid): string
{
    $base = 'https://fansly.com/application/form?r=naughtycamspot';

    return go_append_subid($base, $subid);
}
