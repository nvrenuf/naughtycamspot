# Sample Content Calendar (Week)

Mon: Launch post + teaser clip
Tue: Stream night (goal ladder focus)
Wed: Rest / community post
Thu: Stream night (retention prompts)
Fri: High-energy stream + VIP upsell
Sat: Short Q&A stream
Sun: Schedule update + next-week goals

Keep posts consistent, never share passwords, and follow platform rules.
